

public class LCS {
	
	public static int lcs_length (String X, String Y) {
		/*
		 * fill in your code here
		 * Note: return the length of LCS, instead of c and b
		 */
		int m = X.length();
		int n = Y.length();
		int[][] P = new int[m + 1][n+1];
		
		for(int i = 0; i <= m; i++) {
			for(int j = 0; j <=n;j++) {
				if(i==0 || j == 0) {
					P[i][j] = 0;
				}else if(X.charAt(i-1) == Y.charAt(j-1)) {
					P[i][j] = 1 + P[i-1][j-1];
				}else {
					P[i][j] = Math.max(P[i-1][j],P[i][j-1]);
				}
			}
		}
		return P[m][n];
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(LCS.lcs_length("ABCBDAB", "BDCABA"));
		System.out.println(LCS.lcs_length("ACCGGTCGAGTGCGCGGAAGCCGGCCGAA", "GTCGTTCGGAATGCCGTTGCTCTGTAAA"));
	}

}
