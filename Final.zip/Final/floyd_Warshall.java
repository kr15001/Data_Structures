
import java.util.*;
import java.lang.*;
import java.io.*;

public class floyd_Warshall {
	private static int INF = 999999;
	
	 void  Algorithm(int[][] graph){
		int num = graph.length;
		
		int d[][] = new int[num][num];
		for(int i = 0; i < num; i++) {
			for(int j = 0; j < num; j++) {
				d[i][j] = graph[i][j];
			}
		}
		for(int k = 0; k < num; k++) {
			for(int i = 0; i < num; i++) {
				for(int j = 0; j < num; j++) {
					if(d[i][k] + d[k][j] < d[i][j]) {
						d[i][j] = d[i][k] + d[k][j];
					}
				}
			}
		}
		
		PrintDistance(d);
	}
	public static void PrintDistance(int dist[][] ) {
		int c = 5;
		System.out.println(" The matrice shows the shortest distances between each pair");
		for(int i =0; i <c; ++i) {
			for(int j=0; j<c; ++j) {
				if(dist[i][j] == INF) {
					System.out.println("INF");
				}else {
						System.out.println(dist[i][j]+"  ");
				}
			}
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[][] matrice = { {0, 3,8,INF,-4},
                		    {INF, 0,INF, 1,7},
                		    {INF,4, 0,INF,INF},
                		    {2, INF,-5, 0, INF},
                		    {INF, INF, INF,6, 0}
		};
		floyd_Warshall A = new floyd_Warshall();
		
		A.Algorithm(matrice);
	}

}
