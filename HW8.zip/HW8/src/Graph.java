

import java.util.*;
import java.lang.*;
import java.io.*;

public class Graph {
	public int n;	//number of vertice
	public int[][] A;	//the adjacency matrix
	private final int WHITE = 2;
	private final int GRAY = 3;
	private final int BLACK = 4;
	
	public Graph () {
		n = 0;
		A = null;
	}
	
	public Graph (int _n, int[][] _A) {
		this.n = _n;
		this.A = _A;
	}
	
	
	public int[] bfs (int s) {
		int V = n;
		int dist[][] = new int[V][V];
		int i, j, k;
		for (i = 0; i < V; i++)
		for (j = 0; j < V; j++)
		dist[i][j] = A[i][j];
		for (i = 0; i < V; i++)
		{
		for (j = 0; j < V; j++)
		{
		if (dist[i][s] + dist[s][j] < dist[i][j])
		dist[i][j] = dist[i][s] + dist[s][j];
		}
	}
		int[] distancesFromS = new int[V];
		for(int p=0;p<V;p++) {
		distancesFromS[p] = dist[p][s];
		}
		return distancesFromS;
	}
		
	
	public void print_array (int[] array) {
		for (int i = 0; i < array.length; i++)
			System.out.println(i + ": " + array[i]);
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n = 8;
		int[][] A = 
			{{0, 1, 0, 0, 1, 0, 0, 0},
			{1, 0, 0, 0, 0, 1, 0, 0},
			{0, 0, 0, 1, 0, 1, 1, 0},
			{0, 0, 1, 0, 0, 0, 1, 1},
			{1, 0, 0, 0, 0, 0, 0, 0},
			{0, 1, 1, 0, 0, 0, 1, 0},
			{0, 0, 1, 1, 0, 1, 0, 1},
			{0, 0, 0, 1, 0, 0, 1, 0}};
		Graph g = new Graph(n, A);
		g.print_array(g.bfs(1));
	}

}
